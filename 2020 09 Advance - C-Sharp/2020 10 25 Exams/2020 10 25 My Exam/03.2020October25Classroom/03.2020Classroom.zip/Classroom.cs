﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassroomProject
{
    public class Classroom
    {
        private List<Student> students;

        public Classroom(int capacity)
        {
            this.Capacity = capacity;
            this.Students = new List<Student>();
        }

        public string RegisterStudent(Student student)
        {
            StringBuilder regStudents = new StringBuilder();

            if (this.Capacity > this.students.Count)
            {
                this.students.Add(student);
                regStudents.AppendLine($"Added student {student.FirstName} {student.LastName}");
            }

            else
            {
                regStudents.AppendLine("No seats in the classroom");
            }

            string registerStudent = regStudents.ToString().Trim();
            return registerStudent;
        }

        public string DismissStudent(string firstName, string lastName)
        {
            bool isExist = students.Exists(s => s.FirstName == firstName && s.LastName == lastName);
            StringBuilder dismissStudent = new StringBuilder();
            if (isExist)
            {
                students.RemoveAll(s => s.FirstName == firstName && s.LastName == lastName);
                dismissStudent.AppendLine($"Dismissed student {firstName} {lastName}");
            }

            else
            {
                dismissStudent.AppendLine("Student not found");
            }

            string returnedStudent = dismissStudent.ToString().Trim();
            return returnedStudent;
        }

        public string GetSubjectInfo(string subject)
        {
            StringBuilder sb = new StringBuilder();

            if (students.Exists(s => s.Subject == subject))
            {
                sb.AppendLine($"Subject: {subject}");       //trim
                sb.AppendLine("Students:");
                foreach (var current in students)
                {
                    if (current.Subject == subject)
                    {
                        sb.AppendLine($"{current.FirstName} {current.LastName}");
                    }
                }
            }

            else
            {
                sb.AppendLine("No students enrolled for the subject");
            }

            string statistics = sb.ToString().Trim();
            return statistics;
        }

        //public int GetStudentsCount()
        //{
        //    if (this.students.Count == 0)
        //    {
        //        return 0;
        //    }

        //    else
        //    {
        //        return this.students.Count;
        //    }
        //}

        public Student GetStudent(string firstName, string lastName)
        {
            return this.students.Find(s => s.FirstName == firstName && s.LastName == lastName);
        }

        public List<Student> Students
        {
            get { return this.students; }
            set { this.students = value; }
        }

        public int Capacity { get; set; }
        public int Count
        {
            get { return this.students.Count; }
        }

    }
}
