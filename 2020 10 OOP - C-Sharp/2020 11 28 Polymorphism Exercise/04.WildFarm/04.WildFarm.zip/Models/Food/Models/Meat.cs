﻿namespace _04.WildFarm.Models.Food.Models
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {

        }
    }
}
