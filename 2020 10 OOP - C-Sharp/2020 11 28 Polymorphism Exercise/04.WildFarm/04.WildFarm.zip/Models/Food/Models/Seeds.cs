﻿namespace _04.WildFarm.Models.Food.Models
{
    public class Seeds : Food
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}
