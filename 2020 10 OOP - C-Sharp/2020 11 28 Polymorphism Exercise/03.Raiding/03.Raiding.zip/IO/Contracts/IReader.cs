﻿namespace _03.Raiding.IO.Contracts
{
    public interface IReader
    {
        string ReadLIne();
    }
}
