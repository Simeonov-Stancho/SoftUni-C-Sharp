﻿using System;

namespace _03.Raiding.IO.Contracts
{
    public interface IWriter
    {
        void WriteLine(string text);
    }
}
