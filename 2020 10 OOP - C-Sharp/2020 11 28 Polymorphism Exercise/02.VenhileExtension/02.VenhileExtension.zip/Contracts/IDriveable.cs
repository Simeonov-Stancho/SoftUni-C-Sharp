﻿namespace _01.VehiclesKristiyanIvanov.Contracts
{
    public interface IDriveable
    {
        string Drive(double distance);
    }
}