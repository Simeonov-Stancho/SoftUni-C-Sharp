﻿namespace _01.VehiclesKristiyanIvanov.Contracts
{
    public interface IRefuelable
    {
        void Refuel(double liters);
    }
}