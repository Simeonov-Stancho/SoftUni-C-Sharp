﻿namespace _01.VehiclesKristiyanIvanov.Core.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
