﻿namespace _01.VehiclesKristiyanIvanov.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
