﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Dog mecho = new Dog();
            mecho.Eat();
            mecho.Bark();
        }
    }
}
