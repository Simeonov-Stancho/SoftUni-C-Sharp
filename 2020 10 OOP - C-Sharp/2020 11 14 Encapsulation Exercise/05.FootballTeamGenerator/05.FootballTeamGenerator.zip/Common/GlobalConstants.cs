﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.FootballTeamGenerator.Common
{
    public static class GlobalConstants
    {
        public const string INVALID_NAME_EXC_MSG = "A name should not be empty.";
        public const string MISSING_TEAM_EXC_MSG = "Team {0} does not exist.";
    }
}
