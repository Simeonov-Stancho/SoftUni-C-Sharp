﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl.Contracts
{
    public interface IInhabitable
    {
        string ID { get; }
    }
}