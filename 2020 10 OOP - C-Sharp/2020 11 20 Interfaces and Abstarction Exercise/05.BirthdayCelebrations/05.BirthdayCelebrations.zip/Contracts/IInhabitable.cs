﻿namespace _05.BirthdayCelebrations.Contracts
{
    public interface IInhabitable
    {
        string ID { get; }
    }
}