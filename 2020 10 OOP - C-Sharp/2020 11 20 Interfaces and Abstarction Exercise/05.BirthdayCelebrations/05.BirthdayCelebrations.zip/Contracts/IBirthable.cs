﻿namespace _05.BirthdayCelebrations.Contracts
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}