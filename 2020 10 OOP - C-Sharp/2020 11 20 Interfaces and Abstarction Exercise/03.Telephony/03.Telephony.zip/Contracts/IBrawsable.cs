﻿namespace _03.Telephony.Contracts
{
    public interface IBrawsable
    {
        string Brawse(string url);
    }
}