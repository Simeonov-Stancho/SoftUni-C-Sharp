﻿using _03.Telephony.Core;

namespace _03.Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}