﻿namespace _07.MilitaryElite.Enumeration
{
   public enum State
    {
        inProgress = 1,
        Finished = 2,
    }
}
