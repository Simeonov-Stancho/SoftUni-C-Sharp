﻿namespace _07.MilitaryElite.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
