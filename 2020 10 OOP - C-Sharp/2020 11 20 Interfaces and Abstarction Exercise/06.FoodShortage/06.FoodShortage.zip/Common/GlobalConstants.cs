﻿namespace _06.FoodShortage.Common
{
    public class GlobalConstants
    {
        public const int STARTING_FOOD = 0;
    }
}
