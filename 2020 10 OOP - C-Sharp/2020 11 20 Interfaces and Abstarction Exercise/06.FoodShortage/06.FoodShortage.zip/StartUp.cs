﻿using System;

using _06.FoodShortage.Core;

namespace _06.FoodShortage
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
