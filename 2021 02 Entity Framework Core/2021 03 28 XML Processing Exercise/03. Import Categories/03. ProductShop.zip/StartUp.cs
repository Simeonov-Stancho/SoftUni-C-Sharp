﻿using AutoMapper;
using ProductShop.Data;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        private static string DatasetsDirectoryPath = "../../../Datasets";
        private static string ResultDirectoryPath = "../../../Datasets/Results/";

        public static void Main(string[] args)
        {
            var db = new ProductShopContext();
            InitializeMapper();

            //01. Import Users
            //var inputUsersXml = File.ReadAllText($"{DatasetsDirectoryPath}/users.xml");
            //Console.WriteLine(ImportUsers(db, inputUsersXml));

            //02. Import Products
            //var inputProductsXml = File.ReadAllText($"{DatasetsDirectoryPath}/products.xml");
            //Console.WriteLine(ImportProducts(db, inputProductsXml));

            //03. Import Categories
            var inputCategoriesXml = File.ReadAllText($"{DatasetsDirectoryPath}/categories.xml");
            Console.WriteLine(ImportCategories(db, inputCategoriesXml));

            //04. Import Categories and Products

            //05. Export Products In Range

            //06. Export Sold Products

            //07. Export Categories By Products Count

            //08. Export Users and Products
        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            InitializeMapper();

            var xmlRoot = new XmlRootAttribute("Users");
            var xmlSerializer = new XmlSerializer(typeof(List<UserDto>), xmlRoot);

            var usersDto = (List<UserDto>)xmlSerializer.Deserialize(new StringReader(inputXml));

            var users = Mapper.Map<List<User>>(usersDto);

            context.Users.AddRange(users);

            return $"Successfully imported {context.SaveChanges()}";
        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            var xmlRoot = new XmlRootAttribute("Products");
            var xmlSerializer = new XmlSerializer(typeof(List<ProductDto>), xmlRoot);

            var productsDto = (List<ProductDto>)xmlSerializer.Deserialize(new StringReader(inputXml));

            List<Product> productsForJudge = new List<Product>();

            foreach (var product in productsDto)
            {
                Product productJudge = new Product()
                {
                    Name = product.Name,
                    Price = product.Price,
                    SellerId = product.SellerId,
                    BuyerId = product.BuyerId,
                };

                productsForJudge.Add(productJudge);
            }

            //var products = Mapper.Map<List<Product>>(productsDto);  not working in  judge

            context.Products.AddRange(productsForJudge);
            context.SaveChanges();

            return $"Successfully imported {productsForJudge.Count}";
        }

        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            //InitializeMapper();

            var xmlRoot = new XmlRootAttribute("Categories");
            var xmlSerializer = new XmlSerializer(typeof(List<CategoryDto>), xmlRoot);

            var categoriesDto = (List<CategoryDto>)xmlSerializer.Deserialize(new StringReader(inputXml));

            //Not working in judge
            //var categories = Mapper.Map<List<Category>>(categoriesDto);
            //context.Categories.AddRange(categories);

            List<Category> categoriesForJudge = new List<Category>();

            foreach (var category in categoriesDto)
            {
                Category categoryForJudge = new Category()
                {
                    Name = category.Name
                };

                if (!categoriesForJudge.Any(c => c.Name == categoryForJudge.Name))
                {
                    categoriesForJudge.Add(categoryForJudge);
                }
            }

            context.Categories.AddRange(categoriesForJudge);

            context.SaveChanges();

            return $"Successfully imported {categoriesForJudge.Count}";
        }

        public static void ResetDatabese(ProductShopContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
        }

        private static void InitializeMapper()
        {
            Mapper.Initialize(cfg => { cfg.AddProfile<ProductShopProfile>(); });
        }
    }
}