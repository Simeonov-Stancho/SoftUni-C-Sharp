﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs
{
    public class CategoryInputModelDto
    {
        public string Name { get; set; }
    }
}
